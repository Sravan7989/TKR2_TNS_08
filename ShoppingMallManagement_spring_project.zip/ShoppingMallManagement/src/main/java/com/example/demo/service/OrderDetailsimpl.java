package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.OrderDetails;
import com.example.demo.rep.OrderDetailsRepo;

@Service
public class OrderDetailsimpl implements OrderDetailsService {
	@Autowired
	private OrderDetailsRepo orderdetailsRepo;
	
	@Override
	public OrderDetails saveOrderDetails(OrderDetails orderdetails) {
		return orderdetailsRepo.save(orderdetails);
		
	}
	@Override
    public List<OrderDetails> fetchOrderDetailsList() {
        return orderdetailsRepo.findAll();
    }

   @Override
   public OrderDetails fetchOrderDetailsById(Long orderdetailsId) {
	   return orderdetailsRepo.findById(orderdetailsId).get();
   }
	
   @Override
   public void deleteOrderDetailsById(Long orderdetailsId) {
	   orderdetailsRepo.deleteById(orderdetailsId);
   }


   @Override
   public OrderDetails updateOrderDetails(Long orderdetailsId, OrderDetails orderdetails) {
	   OrderDetails orderDB = orderdetailsRepo.findById(orderdetailsId).get();

       if(Objects.nonNull(orderdetails.getDateOfPurchase())){
    	   orderDB.setDateOfPurchase(orderdetails.getDateOfPurchase());
       }

       if(Objects.nonNull(orderdetails.getTotal())){
    	   orderDB.setTotal(orderdetails.getTotal());
       }

       return orderdetailsRepo.save(orderDB);
   }
}
