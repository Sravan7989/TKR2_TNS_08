package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.OrderDetails;
import com.example.demo.service.OrderDetailsService;
@RestController
public class OrderDetailsController {

	@Autowired
	private OrderDetailsService orderdetailsService;
	
	@PostMapping("/orderdetailsvalue")
	public OrderDetails saveOrderDetails(@RequestBody OrderDetails orderdetails) {
		return orderdetailsService.saveOrderDetails(orderdetails);
	}
	
	@GetMapping("/orderdetailsvalue")
	public List<OrderDetails> fetchOrderDetailsList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return orderdetailsService.fetchOrderDetailsList();
    }
    
	@GetMapping("/orderdetailsvalue/{id}")
	public OrderDetails fetchOrderDetailsById(@PathVariable("id") Long orderId)
    {
		return orderdetailsService.fetchOrderDetailsById(orderId);
    }

	@DeleteMapping("/orderdetailsvalue/{id}")
    public String deleteDepartmentById(@PathVariable("id") Long orderId) {
        orderdetailsService.deleteOrderDetailsById(orderId);
        return "The order details is deleted. Renew if needed.";
    }
    
    @PutMapping("/orderdetailsvalue/{id}")
    public OrderDetails updateOrderDetails(@PathVariable("id") Long orderId,
                                       @RequestBody OrderDetails orderdetails) {
        return orderdetailsService.updateOrderDetails(orderId,orderdetails);
    }
}
