package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.OrderDetails;

public interface OrderDetailsService {
	
	public OrderDetails saveOrderDetails(OrderDetails orderdetails);

	public List<OrderDetails> fetchOrderDetailsList();

	public OrderDetails fetchOrderDetailsById(Long orderId);

	public void deleteOrderDetailsById(Long orderId);

	public OrderDetails updateOrderDetails(Long orderId, OrderDetails orderdetails);

}
