package com.example.demo.Services;

import java.util.List;

import com.example.demo.Entity.User;

public interface UserService {
	
	public User saveUser(User user);

	public User fetchUserById(Long id);

	public List<User> fetchUserList();

	public void deleteUserById(Long id);

	public User updateUser(Long id, User user);

	
	}



