package com.example.demo.entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;
	@JsonFormat(pattern = "dd-MM-yy HH:mm:ss")
	private LocalDateTime dateOfPurchase;
	private Float total;
	//private List<Customer>customers;
	//private enum paymentMode{ CARD , CASH , UPI , ONLINEBANKING};
	//private Customer customer;
	//private Shop shop;
	public OrderDetails(Long orderId, LocalDateTime dateOfPurchase, Float total) {
		super();
		this.orderId = orderId;
		this.dateOfPurchase = dateOfPurchase;
		this.total = total;
	}
	public OrderDetails() {
		super();
	}
	public Long getorderId() {
		return orderId;
	}
	public void setId(Long orderId) {
		this.orderId= orderId;
	}
	public LocalDateTime getDateOfPurchase() {
		return dateOfPurchase;
	}
	public void setDateOfPurchase(LocalDateTime dateOfPurchase) {
		this.dateOfPurchase = dateOfPurchase;
	}
	public Float getTotal() {
		return total;
	}
	public void setTotal(Float total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId+ ", dateOfPurchase=" + dateOfPurchase + ", total=" + total + "]";
	}
	
}
