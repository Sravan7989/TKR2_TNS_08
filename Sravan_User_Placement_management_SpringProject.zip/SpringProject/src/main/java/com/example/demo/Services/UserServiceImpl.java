package com.example.demo.Services;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}
	@Override
	public List<User> fetchUserList() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}
	@Override
	public User fetchUserById(Long id) {
		// TODO Auto-generated method stub
		return userRepository.findById(id).get();
	}
	@Override
	public void deleteUserById(Long id) {
		// TODO Auto-generated method stub
		 userRepository.deleteById(id);
	}
	@Override
	public User updateUser(Long id, User user) {
		User use = userRepository.findById(id).get();

		if(Objects.nonNull(user.getName()) && !"".equalsIgnoreCase(user.getName())) {
			           use.setName(user.getName());
			       }

		if(Objects.nonNull(user.getType()) && !"".equalsIgnoreCase(user.getType())) {
			           use.setType(user.getType());
			       }

		if(Objects.nonNull(user.getPassword()) && !"".equalsIgnoreCase(user.getPassword())) {
			           use.setPassword(user.getPassword());
			       }

		
		return userRepository.save(use);
}
	
}
